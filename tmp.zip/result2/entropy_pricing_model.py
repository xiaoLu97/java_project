import sys
import pandas as pd
import numpy as np

sys.stdout.reconfigure(encoding='utf-8')

# ========== 读取数据 ==========
df = pd.read_excel('D:/tmp/定价模型1（用于计算熵权法权重及最终生成定价模型）.xlsx', sheet_name='Sheet1')

indicators = ['项目成本', '医生资质', '时间成本', '技术难度', '风险程度', '供求关系', '市场竞争程度']
n = len(df)
m = len(indicators)

raw_data = df[indicators].values
actual_prices = df['收费单价'].values

# ========== 步骤一：熵权法 ==========
print("=" * 80)
print("步骤一：熵权法计算各指标权重")
print("=" * 80)
print(f"\n项目数量 n = {n}，指标数量 m = {m}")

# 1.1 Min-Max归一化
print("\n【1.1 数据标准化（Min-Max归一化）】")
print("公式：r_ij = (x_ij - min_j) / (max_j - min_j)")
print("所有指标按正向指标处理（值越大，项目要求越高）\n")

normalized = np.zeros((n, m))
for j in range(m):
    col = raw_data[:, j]
    normalized[:, j] = (col - col.min()) / (col.max() - col.min())
    print(f"  {indicators[j]}: min={col.min():.4f}, max={col.max():.4f}")

epsilon = 0.0001
r = normalized + epsilon
print(f"\n坐标平移量 epsilon = {epsilon}，避免 ln(0) 问题")

print("\n归一化结果（前5个项目示例）：")
header = f"{'项目':<18s}"
for ind in indicators:
    header += f"  {ind:>10s}"
print(header)
for i in range(5):
    row = f"{df.iloc[i]['项目名称']:<18s}"
    for j in range(m):
        row += f"  {r[i,j]:>10.6f}"
    print(row)

# 1.2 比重矩阵
print("\n\n【1.2 计算比重矩阵 p_ij】")
print("公式：p_ij = r_ij / SUM(i=1..n) r_ij\n")

p = np.zeros((n, m))
for j in range(m):
    p[:, j] = r[:, j] / r[:, j].sum()

print("比重矩阵（前5个项目示例）：")
header = f"{'项目':<18s}"
for ind in indicators:
    header += f"  {ind:>10s}"
print(header)
for i in range(5):
    row = f"{df.iloc[i]['项目名称']:<18s}"
    for j in range(m):
        row += f"  {p[i,j]:>10.6f}"
    print(row)

# 1.3 信息熵
print("\n\n【1.3 计算信息熵 e_j】")
print("公式：e_j = -k * SUM[i=1..n] p_ij * ln(p_ij)")
print("其中 k = 1/ln(n)")

k = 1.0 / np.log(n)
print(f"k = 1/ln({n}) = {k:.6f}\n")

e = np.zeros(m)
for j in range(m):
    entropy_sum = np.sum(p[:, j] * np.log(p[:, j]))  # p>0 guaranteed by epsilon
    e[j] = -k * entropy_sum

print("各指标信息熵 e_j：")
for j in range(m):
    print(f"  {indicators[j]}: e = {e[j]:.6f}")

# 1.4 差异系数和权重
print("\n\n【1.4 计算差异系数 d_j 和 熵权法权重 w_j】")
print("d_j = 1 - e_j")
print("w_j = d_j / SUM(d_j)\n")

d = 1 - e
w_entropy = d / d.sum()

print(f"{'指标':<12s}  {'信息熵 e_j':>10s}  {'差异系数 d_j':>12s}  {'熵权权重 w_j':>14s}  {'权重(%)':>8s}")
print("-" * 62)
for j in range(m):
    print(f"{indicators[j]:<12s}  {e[j]:>10.6f}  {d[j]:>12.6f}  {w_entropy[j]:>14.6f}  {w_entropy[j]*100:>7.2f}%")
print(f"\n  熵权法权重之和 = {w_entropy.sum():.6f}")

# ========== 步骤二：综合权重与定价模型 ==========
print("\n\n" + "=" * 80)
print("步骤二：综合权重计算与定价模型构建")
print("=" * 80)

# AHP权重
ahp_dict = {
    '项目成本': 0.194727, '医生资质': 0.194471, '时间成本': 0.115401,
    '技术难度': 0.177658, '风险程度': 0.161444, '供求关系': 0.081215, '市场竞争程度': 0.075084
}
ahp_w = np.array([ahp_dict[ind] for ind in indicators])

print("\n【2.1 AHP层次分析法权重（107份问卷，CR=0.0441<0.1）】\n")
print(f"{'指标':<12s}  {'AHP权重':>10s}  {'权重(%)':>8s}")
print("-" * 35)
for j in range(m):
    print(f"{indicators[j]:<12s}  {ahp_w[j]:>10.6f}  {ahp_w[j]*100:>7.2f}%")

# 综合权重（乘法集成法）
print("\n\n【2.2 综合权重（乘法集成法）】")
print("W_j = (w_AHP * w_Entropy) / SUM(w_AHP * w_Entropy)\n")

combined_raw = ahp_w * w_entropy
combined_w = combined_raw / combined_raw.sum()

print(f"{'指标':<12s}  {'AHP(%)':>8s}  {'熵权法(%)':>8s}  {'乘积':>12s}  {'综合权重':>10s}  {'综合(%)':>8s}")
print("-" * 65)
for j in range(m):
    print(f"{indicators[j]:<12s}  {ahp_w[j]*100:>7.2f}%  {w_entropy[j]*100:>7.2f}%  {combined_raw[j]:>12.8f}  {combined_w[j]:>10.6f}  {combined_w[j]*100:>7.2f}%")
print(f"\n  综合权重之和 = {combined_w.sum():.6f}")

# 定价模型
print("\n\n【2.3 手术类项目定价模型】")
print("S_i = SUM(j=1..m) W_j * r_ij  (综合评分)\n")

scores = np.zeros(n)
for i in range(n):
    scores[i] = np.sum(combined_w * r[i, :])

# 线性回归：Price = a * S + b
S_mean, P_mean = scores.mean(), actual_prices.mean()
a = np.sum((scores - S_mean) * (actual_prices - P_mean)) / np.sum((scores - S_mean) ** 2)
b = P_mean - a * S_mean
predicted = a * scores + b

print(f"线性回归：Price_pred = a * S + b")
print(f"  a = {a:.4f}")
print(f"  b = {b:.4f}")
print(f"\n最终定价公式：Price_pred = {a:.4f} * S + {b:.4f}")

# ========== 模型结果对比 ==========
print("\n\n【2.4 定价预测值与实际价格对比】\n")
abs_err = np.abs(predicted - actual_prices)
rel_err = abs_err / actual_prices * 100

print(f"{'#':>3s} {'项目名称':<18s} {'评分S':>8s} {'预测价格':>10s} {'实际价格':>10s} {'绝对误差':>10s} {'相对误差':>8s}")
print("-" * 75)
for i in range(n):
    print(f"{i+1:>3d} {df.iloc[i]['项目名称']:<18s} {scores[i]:>8.4f} {predicted[i]:>10.2f} {actual_prices[i]:>10.2f} {abs_err[i]:>10.2f} {rel_err[i]:>7.2f}%")

# ========== 模型检验 ==========
print("\n\n" + "=" * 80)
print("模型检验统计")
print("=" * 80)

MAE = abs_err.mean()
RMSE = np.sqrt(np.mean((predicted - actual_prices) ** 2))
MAPE = rel_err.mean()
SS_res = np.sum((actual_prices - predicted) ** 2)
SS_tot = np.sum((actual_prices - actual_prices.mean()) ** 2)
R2 = 1 - SS_res / SS_tot

# Pearson相关系数
r_num = np.sum((predicted - predicted.mean()) * (actual_prices - actual_prices.mean()))
r_den = np.sqrt(np.sum((predicted - predicted.mean())**2) * np.sum((actual_prices - actual_prices.mean())**2))
pearson_r = r_num / r_den

# Spearman秩相关
def rankdata(arr):
    temp = arr.argsort()
    ranks = np.empty(len(arr))
    ranks[temp] = np.arange(len(arr)) + 1
    return ranks

rank_pred = rankdata(predicted)
rank_actual = rankdata(actual_prices)
d_sq = np.sum((rank_pred - rank_actual) ** 2)
spearman_r = 1 - 6 * d_sq / (n * (n**2 - 1))

# t检验 (Pearson)
t_stat = pearson_r * np.sqrt((n - 2) / (1 - pearson_r**2))

print(f"\n  平均绝对误差 (MAE)：{MAE:.2f} 元")
print(f"  均方根误差 (RMSE)：{RMSE:.2f} 元")
print(f"  平均绝对百分比误差 (MAPE)：{MAPE:.2f}%")
print(f"  决定系数 R-squared：{R2:.6f}")
print(f"  Pearson相关系数 r：{pearson_r:.6f}")
print(f"  Spearman秩相关系数 rho：{spearman_r:.6f}")
print(f"  t统计量（Pearson显著性）：t = {t_stat:.4f}, df = {n-2}")

print(f"\n  相对误差分布：")
bins = [(0, 10), (10, 20), (20, 30), (30, 50), (50, 100), (100, 999)]
labels = ["<10%", "10%-20%", "20%-30%", "30%-50%", "50%-100%", ">100%"]
for (lo, hi), label in zip(bins, labels):
    cnt = np.sum((rel_err >= lo) & (rel_err < hi))
    print(f"    {label:>10s}：{cnt:>3d} 个项目 ({cnt/n*100:>5.1f}%)")

# ========== 权重对比 ==========
print("\n\n" + "=" * 80)
print("三种权重对比总结")
print("=" * 80)

ahp_order = list(np.argsort(-ahp_w))
ent_order = list(np.argsort(-w_entropy))
com_order = list(np.argsort(-combined_w))

print(f"\n{'指标':<12s}  {'AHP(%)':>8s} {'排名':>4s}  {'熵权法(%)':>8s} {'排名':>4s}  {'综合(%)':>8s} {'排名':>4s}")
print("-" * 60)
for j in range(m):
    print(f"{indicators[j]:<12s}  {ahp_w[j]*100:>7.2f}% {ahp_order.index(j)+1:>4d}  {w_entropy[j]*100:>7.2f}% {ent_order.index(j)+1:>4d}  {combined_w[j]*100:>7.2f}% {com_order.index(j)+1:>4d}")

# ========== 最终模型总结 ==========
print("\n\n" + "=" * 80)
print("最终定价模型总结")
print("=" * 80)
print(f"""
一、熵权法权重（客观权重）:
""")
for j in range(m):
    print(f"   {indicators[j]}: {w_entropy[j]:.6f} ({w_entropy[j]*100:.2f}%)")

print(f"""
二、AHP层次分析法权重（主观权重，107份问卷）:
""")
for j in range(m):
    print(f"   {indicators[j]}: {ahp_w[j]:.6f} ({ahp_w[j]*100:.2f}%)")

print(f"""
三、综合权重（乘法集成法）:
""")
for j in range(m):
    print(f"   {indicators[j]}: {combined_w[j]:.6f} ({combined_w[j]*100:.2f}%)")

print(f"""
四、定价模型:
   综合评分 S = SUM(W_j * r_j)
   预测价格 Price = {a:.4f} * S + {b:.4f}

五、模型检验:
   R-squared = {R2:.6f}
   Pearson r = {pearson_r:.6f}
   Spearman rho = {spearman_r:.6f}
   MAPE = {MAPE:.2f}%
""")
