import sys
import pandas as pd
import numpy as np

sys.stdout.reconfigure(encoding='utf-8')

# ========== 读取数据 & 计算 ==========
df = pd.read_excel('D:/tmp/定价模型1（用于计算熵权法权重及最终生成定价模型）.xlsx', sheet_name='Sheet1')
indicators = ['项目成本', '医生资质', '时间成本', '技术难度', '风险程度', '供求关系', '市场竞争程度']
n = len(df)
m = len(indicators)
raw_data = df[indicators].values
actual_prices = df['收费单价'].values

# 归一化
normalized = np.zeros((n, m))
min_vals = np.zeros(m)
max_vals = np.zeros(m)
for j in range(m):
    col = raw_data[:, j]
    min_vals[j], max_vals[j] = col.min(), col.max()
    normalized[:, j] = (col - min_vals[j]) / (max_vals[j] - min_vals[j])

epsilon = 0.0001
r = normalized + epsilon

# 比重矩阵
p = np.zeros((n, m))
for j in range(m):
    p[:, j] = r[:, j] / r[:, j].sum()

# 信息熵
k = 1.0 / np.log(n)
e = np.zeros(m)
for j in range(m):
    e[j] = -k * np.sum(p[:, j] * np.log(p[:, j]))

# 熵权法权重
d = 1 - e
w_entropy = d / d.sum()

# AHP权重
ahp_dict = {
    '项目成本': 0.194727, '医生资质': 0.194471, '时间成本': 0.115401,
    '技术难度': 0.177658, '风险程度': 0.161444, '供求关系': 0.081215, '市场竞争程度': 0.075084
}
ahp_w = np.array([ahp_dict[ind] for ind in indicators])

# 综合权重
combined_raw = ahp_w * w_entropy
combined_w = combined_raw / combined_raw.sum()

# 综合评分
scores = np.zeros(n)
for i in range(n):
    scores[i] = np.sum(combined_w * r[i, :])

# 线性回归
S_mean, P_mean = scores.mean(), actual_prices.mean()
a_coef = np.sum((scores - S_mean) * (actual_prices - P_mean)) / np.sum((scores - S_mean) ** 2)
b_coef = P_mean - a_coef * S_mean
predicted = a_coef * scores + b_coef

abs_err = np.abs(predicted - actual_prices)
rel_err = abs_err / actual_prices * 100
MAE = abs_err.mean()
RMSE = np.sqrt(np.mean((predicted - actual_prices) ** 2))
MAPE = rel_err.mean()
SS_res = np.sum((actual_prices - predicted) ** 2)
SS_tot = np.sum((actual_prices - actual_prices.mean()) ** 2)
R2 = 1 - SS_res / SS_tot
r_num = np.sum((predicted - predicted.mean()) * (actual_prices - actual_prices.mean()))
r_den = np.sqrt(np.sum((predicted - predicted.mean())**2) * np.sum((actual_prices - actual_prices.mean())**2))
pearson_r = r_num / r_den

def rankdata(arr):
    temp = arr.argsort()
    ranks = np.empty(len(arr))
    ranks[temp] = np.arange(len(arr)) + 1
    return ranks
rank_pred = rankdata(predicted)
rank_actual = rankdata(actual_prices)
spearman_r = 1 - 6 * np.sum((rank_pred - rank_actual)**2) / (n * (n**2 - 1))
t_stat = pearson_r * np.sqrt((n - 2) / (1 - pearson_r**2))

print("计算完成，开始生成文件...")

# ==============================================================================
#  生成 Excel 文件
# ==============================================================================
excel_path = 'D:/tmp/熵权法及定价模型分析结果.xlsx'

with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
    # Sheet1: 原始数据与归一化
    df_norm = pd.DataFrame(r, columns=[f'{ind}_归一化' for ind in indicators])
    df_out1 = pd.concat([df[['项目编码', '项目名称', '收费单价']], df[indicators], df_norm], axis=1)
    df_out1.to_excel(writer, sheet_name='原始数据与归一化', index=False)

    # Sheet2: 比重矩阵
    df_p = pd.DataFrame(p, columns=indicators)
    df_out2 = pd.concat([df[['项目编码', '项目名称']], df_p], axis=1)
    df_out2.to_excel(writer, sheet_name='比重矩阵', index=False)

    # Sheet3: 熵权法计算过程
    entropy_df = pd.DataFrame({
        '指标': indicators,
        '信息熵e_j': e,
        '差异系数d_j': d,
        '熵权法权重': w_entropy,
        '权重(%)': w_entropy * 100
    })
    entropy_df.to_excel(writer, sheet_name='熵权法权重', index=False)

    # Sheet4: 三种权重对比
    weight_df = pd.DataFrame({
        '指标': indicators,
        'AHP权重': ahp_w,
        'AHP(%)': ahp_w * 100,
        '熵权法权重': w_entropy,
        '熵权法(%)': w_entropy * 100,
        'AHP×熵权(乘积)': combined_raw,
        '综合权重': combined_w,
        '综合(%)': combined_w * 100
    })
    weight_df.to_excel(writer, sheet_name='三种权重对比', index=False)

    # Sheet5: 定价模型结果
    result_df = pd.DataFrame({
        '序号': np.arange(1, n + 1),
        '项目编码': df['项目编码'],
        '项目名称': df['项目名称'],
        '综合评分S': scores,
        '预测价格': np.round(predicted, 2),
        '实际收费单价': actual_prices,
        '绝对误差': np.round(abs_err, 2),
        '相对误差(%)': np.round(rel_err, 2)
    })
    result_df.to_excel(writer, sheet_name='定价模型预测对比', index=False)

    # Sheet6: 模型检验统计
    stats_data = {
        '检验指标': ['平均绝对误差(MAE)', '均方根误差(RMSE)', '平均绝对百分比误差(MAPE)',
                   '决定系数R²', 'Pearson相关系数r', 'Spearman秩相关系数ρ',
                   't统计量', '自由度df', '样本量n',
                   '', '相对误差<10%', '10%-20%', '20%-30%', '30%-50%', '50%-100%', '>100%'],
        '数值': [f'{MAE:.2f}元', f'{RMSE:.2f}元', f'{MAPE:.2f}%',
                f'{R2:.6f}', f'{pearson_r:.6f}', f'{spearman_r:.6f}',
                f'{t_stat:.4f}', f'{n-2}', f'{n}',
                '',
                f'{int(np.sum(rel_err < 10))}个({np.sum(rel_err < 10)/n*100:.1f}%)',
                f'{int(np.sum((rel_err >= 10) & (rel_err < 20)))}个({np.sum((rel_err >= 10) & (rel_err < 20))/n*100:.1f}%)',
                f'{int(np.sum((rel_err >= 20) & (rel_err < 30)))}个({np.sum((rel_err >= 20) & (rel_err < 30))/n*100:.1f}%)',
                f'{int(np.sum((rel_err >= 30) & (rel_err < 50)))}个({np.sum((rel_err >= 30) & (rel_err < 50))/n*100:.1f}%)',
                f'{int(np.sum((rel_err >= 50) & (rel_err < 100)))}个({np.sum((rel_err >= 50) & (rel_err < 100))/n*100:.1f}%)',
                f'{int(np.sum(rel_err >= 100))}个({np.sum(rel_err >= 100)/n*100:.1f}%)'],
        '说明': ['预测值与实际值的平均偏差', '误差的标准差', '平均相对偏差百分比',
                '模型解释的变异比例(越接近1越好)', '线性相关程度', '排序相关程度',
                'Pearson相关系数的t检验统计量', 'n-2', '手术项目总数',
                '', '预测非常准确', '预测较准确', '可接受范围', '偏差较大', '偏差大', '偏差极大']
    }
    pd.DataFrame(stats_data).to_excel(writer, sheet_name='模型检验统计', index=False)

    # Sheet7: 定价模型公式
    formula_data = {
        '项目': ['定价公式', '系数a', '截距b', '综合评分公式', '归一化公式', '综合权重方法',
                '项目成本综合权重', '医生资质综合权重', '时间成本综合权重', '技术难度综合权重',
                '风险程度综合权重', '供求关系综合权重', '市场竞争程度综合权重'],
        '值': [f'Price = {a_coef:.4f} * S + ({b_coef:.4f})',
              f'{a_coef:.4f}', f'{b_coef:.4f}',
              'S = Σ(Wj × rj)', 'r_ij = (x_ij - min) / (max - min) + ε',
              '乘法集成法: W = (w_AHP × w_Entropy) / Σ(w_AHP × w_Entropy)',
              f'{combined_w[0]:.6f} ({combined_w[0]*100:.2f}%)',
              f'{combined_w[1]:.6f} ({combined_w[1]*100:.2f}%)',
              f'{combined_w[2]:.6f} ({combined_w[2]*100:.2f}%)',
              f'{combined_w[3]:.6f} ({combined_w[3]*100:.2f}%)',
              f'{combined_w[4]:.6f} ({combined_w[4]*100:.2f}%)',
              f'{combined_w[5]:.6f} ({combined_w[5]*100:.2f}%)',
              f'{combined_w[6]:.6f} ({combined_w[6]*100:.2f}%)']
    }
    pd.DataFrame(formula_data).to_excel(writer, sheet_name='定价模型公式', index=False)

print(f"Excel 文件已生成: {excel_path}")

# ==============================================================================
#  生成 HTML 报告
# ==============================================================================
html_path = 'D:/tmp/熵权法及定价模型分析报告.html'

# 准备权重柱状图数据
weight_bars_html = ""
for j in range(m):
    w_pct = combined_w[j] * 100
    weight_bars_html += f"""
    <tr>
      <td class="row-header">{indicators[j]}</td>
      <td><div class="weight-bar-wrapper">
        <div class="weight-bar" style="width: {w_pct * 2.5}px;"></div>
        <span class="weight-pct">{w_pct:.2f}%</span>
      </div></td>
      <td class="num">{combined_w[j]:.6f}</td>
    </tr>"""

# 三种权重对比柱状图
triple_bars_html = ""
for j in range(m):
    triple_bars_html += f"""
    <tr>
      <td class="row-header">{indicators[j]}</td>
      <td><div class="triple-bar-wrapper">
        <span class="bar-label">AHP</span>
        <div class="weight-bar bar-ahp" style="width: {ahp_w[j]*250}px;"></div>
        <span class="weight-pct">{ahp_w[j]*100:.2f}%</span>
      </div></td>
      <td><div class="triple-bar-wrapper">
        <span class="bar-label">熵权</span>
        <div class="weight-bar bar-entropy" style="width: {w_entropy[j]*250}px;"></div>
        <span class="weight-pct">{w_entropy[j]*100:.2f}%</span>
      </div></td>
      <td><div class="triple-bar-wrapper">
        <span class="bar-label">综合</span>
        <div class="weight-bar bar-combined" style="width: {combined_w[j]*250}px;"></div>
        <span class="weight-pct">{combined_w[j]*100:.2f}%</span>
      </div></td>
    </tr>"""

# 定价对比表
price_table_html = ""
for i in range(n):
    err_class = ""
    if rel_err[i] < 10:
        err_class = "err-good"
    elif rel_err[i] < 20:
        err_class = "err-ok"
    elif rel_err[i] < 30:
        err_class = "err-warn"
    elif rel_err[i] < 50:
        err_class = "err-bad"
    else:
        err_class = "err-very-bad"
    price_table_html += f"""
    <tr>
      <td>{i+1}</td>
      <td>{df.iloc[i]['项目编码']}</td>
      <td class="name-cell">{df.iloc[i]['项目名称']}</td>
      <td>{scores[i]:.4f}</td>
      <td class="num">{predicted[i]:.2f}</td>
      <td class="num">{actual_prices[i]:.2f}</td>
      <td class="num">{abs_err[i]:.2f}</td>
      <td class="{err_class}">{rel_err[i]:.2f}%</td>
    </tr>"""

# 熵权法过程表
entropy_table_html = ""
for j in range(m):
    entropy_table_html += f"""
    <tr>
      <td class="row-header">{indicators[j]}</td>
      <td class="num">{min_vals[j]:.4f}</td>
      <td class="num">{max_vals[j]:.4f}</td>
      <td class="num">{e[j]:.6f}</td>
      <td class="num">{d[j]:.6f}</td>
      <td class="num highlight">{w_entropy[j]:.6f}</td>
      <td class="num highlight">{w_entropy[j]*100:.2f}%</td>
    </tr>"""

# 散点图数据（用 SVG）
svg_width, svg_height = 600, 400
margin = 60
plot_w = svg_width - 2 * margin
plot_h = svg_height - 2 * margin

min_pred, max_pred = predicted.min() * 0.9, max(predicted.max(), actual_prices.max()) * 1.05
min_act, max_act = actual_prices.min() * 0.9, max(predicted.max(), actual_prices.max()) * 1.05
axis_max = max(max_pred, max_act)

def sx(val):
    return margin + (val / axis_max) * plot_w
def sy(val):
    return margin + plot_h - (val / axis_max) * plot_h

# 散点
scatter_dots = ""
for i in range(n):
    scatter_dots += f'<circle cx="{sx(predicted[i]):.1f}" cy="{sy(actual_prices[i]):.1f}" r="4" class="dot" />'

# 理想线 (y=x)
line_end = axis_max * 0.95
scatter_dots += f'<line x1="{sx(0):.1f}" y1="{sy(0):.1f}" x2="{sx(line_end):.1f}" y2="{sy(line_end):.1f}" class="ideal-line" />'

# 坐标轴刻度
x_ticks = ""
y_ticks = ""
for v in [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000]:
    if v <= axis_max:
        x_ticks += f'<text x="{sx(v):.1f}" y="{sy(0)+20:.1f}" class="tick-label" text-anchor="middle">{v}</text>'
        x_ticks += f'<line x1="{sx(v):.1f}" y1="{sy(0):.1f}" x2="{sx(v):.1f}" y2="{sy(0)+5:.1f}" class="tick-line" />'
        y_ticks += f'<text x="{sx(0)-8:.1f}" y="{sy(v)+4:.1f}" class="tick-label" text-anchor="end">{v}</text>'
        y_ticks += f'<line x1="{sx(0)-5:.1f}" y1="{sy(v):.1f}" x2="{sx(0):.1f}" y2="{sy(v):.1f}" class="tick-line" />'

html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>熵权法及定价模型分析报告</title>
<style>
:root {{
  --primary: #4f46e5; --primary-light: #818cf8; --success: #10b981;
  --warning: #f59e0b; --danger: #ef4444; --gray-50: #f9fafb;
  --gray-100: #f3f4f6; --gray-200: #e5e7eb; --gray-300: #d1d5db;
  --gray-600: #4b5563; --gray-700: #374151; --gray-800: #1f2937;
}}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft YaHei', sans-serif;
  background: var(--gray-50); color: var(--gray-800); line-height: 1.6; padding: 20px; }}
.container {{ max-width: 1100px; margin: 0 auto; }}
.header {{ background: linear-gradient(135deg, #4f46e5, #7c3aed); color: white; padding: 40px;
  border-radius: 16px; margin-bottom: 24px; text-align: center; }}
.header h1 {{ font-size: 28px; margin-bottom: 8px; }}
.header .subtitle {{ opacity: 0.9; font-size: 15px; }}
.card {{ background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08); border: 1px solid var(--gray-200); }}
.card h2 {{ font-size: 20px; color: var(--primary); margin-bottom: 16px;
  padding-bottom: 8px; border-bottom: 2px solid var(--gray-100); }}
.card h3 {{ font-size: 16px; color: var(--gray-700); margin: 16px 0 10px; }}
.stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px; margin: 16px 0; }}
.stat-box {{ background: var(--gray-50); border-radius: 10px; padding: 16px; text-align: center;
  border: 1px solid var(--gray-200); }}
.stat-box .label {{ font-size: 12px; color: var(--gray-600); margin-bottom: 4px; }}
.stat-box .num {{ font-size: 26px; font-weight: 700; color: var(--primary); }}
.stat-box .unit {{ font-size: 12px; color: var(--gray-600); }}
table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
table th {{ background: var(--gray-100); padding: 10px 12px; text-align: center;
  font-weight: 600; border-bottom: 2px solid var(--gray-300); }}
table td {{ padding: 8px 12px; border-bottom: 1px solid var(--gray-100); }}
table tr:hover {{ background: var(--gray-50); }}
table .row-header {{ text-align: left; font-weight: 600; background: var(--gray-100); }}
table .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
table .highlight {{ color: var(--primary); font-weight: 600; }}
table .name-cell {{ max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
table .err-good {{ background: #d1fae5; color: #065f46; font-weight: 600; text-align: right; }}
table .err-ok {{ background: #dbeafe; color: #1e40af; font-weight: 500; text-align: right; }}
table .err-warn {{ background: #fef3c7; color: #92400e; font-weight: 500; text-align: right; }}
table .err-bad {{ background: #fed7aa; color: #9a3412; font-weight: 500; text-align: right; }}
table .err-very-bad {{ background: #fecaca; color: #991b1b; font-weight: 600; text-align: right; }}
.weight-bar-wrapper {{ display: flex; align-items: center; gap: 8px; }}
.weight-bar {{ height: 20px; border-radius: 4px; transition: width 0.3s; }}
.bar-ahp {{ background: linear-gradient(90deg, #3b82f6, #6366f1); }}
.bar-entropy {{ background: linear-gradient(90deg, #10b981, #059669); }}
.bar-combined {{ background: linear-gradient(90deg, #f59e0b, #d97706); }}
.weight-pct {{ font-size: 12px; font-weight: 600; color: var(--gray-700); white-space: nowrap; }}
.triple-bar-wrapper {{ display: flex; align-items: center; gap: 6px; }}
.bar-label {{ font-size: 11px; color: var(--gray-600); width: 28px; }}
.formula {{ background: var(--gray-50); border: 1px solid var(--gray-200); border-radius: 8px;
  padding: 16px; margin: 12px 0; font-family: 'Cambria Math', serif; font-size: 15px;
  text-align: center; color: var(--gray-800); }}
.scatter-container {{ text-align: center; margin: 16px 0; }}
.dot {{ fill: var(--primary); opacity: 0.7; }}
.dot:hover {{ fill: var(--danger); opacity: 1; r: 6; }}
.ideal-line {{ stroke: var(--danger); stroke-width: 1.5; stroke-dasharray: 6,4; opacity: 0.6; }}
.tick-label {{ font-size: 11px; fill: var(--gray-600); }}
.tick-line {{ stroke: var(--gray-300); stroke-width: 1; }}
.axis-label {{ font-size: 13px; fill: var(--gray-700); font-weight: 600; }}
.legend {{ display: flex; gap: 20px; justify-content: center; margin-top: 8px; font-size: 12px; }}
.legend-item {{ display: flex; align-items: center; gap: 4px; }}
.legend-dot {{ width: 10px; height: 10px; border-radius: 50%; }}
.conclusion {{ background: linear-gradient(135deg, #eef2ff, #e0e7ff); border-left: 4px solid var(--primary);
  padding: 16px 20px; border-radius: 0 8px 8px 0; margin: 16px 0; }}
.conclusion p {{ margin: 6px 0; }}
.scroll-table {{ max-height: 500px; overflow-y: auto; }}
.section-badge {{ display: inline-block; background: var(--primary); color: white; padding: 2px 10px;
  border-radius: 12px; font-size: 12px; font-weight: 600; margin-right: 8px; }}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>熵权法及手术类项目定价模型分析报告</h1>
  <div class="subtitle">基于60个手术类项目 · 7项评价指标 · 熵权法+AHP综合权重 · 线性回归定价模型</div>
</div>

<!-- 概览统计 -->
<div class="card">
  <h2><span class="section-badge">概览</span>核心统计指标</h2>
  <div class="stats-grid">
    <div class="stat-box"><div class="label">手术项目数</div><div class="num">60</div></div>
    <div class="stat-box"><div class="label">评价指标数</div><div class="num">7</div></div>
    <div class="stat-box"><div class="label">决定系数 R²</div><div class="num">{R2:.4f}</div><div class="unit">模型拟合优度</div></div>
    <div class="stat-box"><div class="label">Pearson r</div><div class="num">{pearson_r:.4f}</div><div class="unit">线性相关系数</div></div>
    <div class="stat-box"><div class="label">Spearman ρ</div><div class="num">{spearman_r:.4f}</div><div class="unit">秩相关系数</div></div>
    <div class="stat-box"><div class="label">MAPE</div><div class="num">{MAPE:.1f}%</div><div class="unit">平均相对误差</div></div>
  </div>
</div>

<!-- 步骤一：熵权法 -->
<div class="card">
  <h2><span class="section-badge">步骤一</span>熵权法计算各指标权重</h2>

  <h3>1.1 计算方法</h3>
  <div class="formula">
    r<sub>ij</sub> = (x<sub>ij</sub> - min) / (max - min) + ε &nbsp;&nbsp;→&nbsp;&nbsp;
    p<sub>ij</sub> = r<sub>ij</sub> / Σr<sub>ij</sub> &nbsp;&nbsp;→&nbsp;&nbsp;
    e<sub>j</sub> = -k·Σp<sub>ij</sub>·ln(p<sub>ij</sub>) &nbsp;&nbsp;→&nbsp;&nbsp;
    w<sub>j</sub> = (1-e<sub>j</sub>) / Σ(1-e<sub>j</sub>)
  </div>
  <p style="font-size:13px;color:var(--gray-600);">其中 k = 1/ln(n) = 1/ln(60) = {k:.6f}，ε = {epsilon}（坐标平移，避免ln(0)）</p>

  <h3>1.2 熵权法权重结果</h3>
  <table>
    <thead><tr>
      <th>指标</th><th>最小值</th><th>最大值</th><th>信息熵 e<sub>j</sub></th>
      <th>差异系数 d<sub>j</sub></th><th>权重 w<sub>j</sub></th><th>权重(%)</th>
    </tr></thead>
    <tbody>{entropy_table_html}</tbody>
  </table>

  <h3>1.3 熵权法权重分布</h3>
  <div class="scatter-container">
    <svg width="600" height="180" viewBox="0 0 600 180">
      {" ".join(f'<rect x="{20 + j*82}" y="{160 - w_entropy[j]*500}" width="60" height="{w_entropy[j]*500}" rx="4" fill="url(#barGrad)" /><text x="{50 + j*82}" y="{150 - w_entropy[j]*500}" text-anchor="middle" font-size="12" font-weight="600" fill="#4f46e5">{w_entropy[j]*100:.1f}%</text><text x="{50 + j*82}" y="175" text-anchor="middle" font-size="10" fill="#374151">{indicators[j][:4]}</text>' for j in range(m))}
      <defs><linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#10b981"/><stop offset="100%" stop-color="#059669"/>
      </linearGradient></defs>
    </svg>
  </div>
  <div class="conclusion">
    <p><strong>熵权法分析结论：</strong>从客观数据差异角度看，<strong>市场竞争程度（{w_entropy[6]*100:.2f}%）</strong>和<strong>项目成本（{w_entropy[0]*100:.2f}%）</strong>在60个项目间差异最大，权重最高；<strong>医生资质（{w_entropy[1]*100:.2f}%）</strong>和<strong>技术难度（{w_entropy[3]*100:.2f}%）</strong>差异较小，权重较低。</p>
  </div>
</div>

<!-- 步骤二：综合权重 -->
<div class="card">
  <h2><span class="section-badge">步骤二</span>综合权重计算（乘法集成法）</h2>

  <h3>2.1 AHP权重（107份问卷几何平均，CR=0.0441&lt;0.1）</h3>
  <table>
    <thead><tr><th>指标</th><th>AHP权重</th><th>AHP(%)</th></tr></thead>
    <tbody>
      {"".join(f'<tr><td class="row-header">{indicators[j]}</td><td class="num">{ahp_w[j]:.6f}</td><td class="num">{ahp_w[j]*100:.2f}%</td></tr>' for j in range(m))}
    </tbody>
  </table>

  <h3>2.2 综合权重（乘法集成法）</h3>
  <div class="formula">
    W<sub>j</sub> = (w<sub>AHP</sub> × w<sub>Entropy</sub>) / Σ(w<sub>AHP</sub> × w<sub>Entropy</sub>)
  </div>
  <table>
    <thead><tr><th>指标</th><th>AHP权重</th><th>熵权法权重</th><th>乘积</th><th>综合权重</th><th>综合(%)</th></tr></thead>
    <tbody>
      {"".join(f'<tr><td class="row-header">{indicators[j]}</td><td class="num">{ahp_w[j]:.6f}</td><td class="num">{w_entropy[j]:.6f}</td><td class="num">{combined_raw[j]:.8f}</td><td class="num highlight">{combined_w[j]:.6f}</td><td class="num highlight">{combined_w[j]*100:.2f}%</td></tr>' for j in range(m))}
      <tr style="font-weight:600;background:var(--gray-50)"><td>合计</td><td class="num">{ahp_w.sum():.6f}</td><td class="num">{w_entropy.sum():.6f}</td><td></td><td class="num">{combined_w.sum():.6f}</td><td class="num">{combined_w.sum()*100:.2f}%</td></tr>
    </tbody>
  </table>

  <h3>2.3 三种权重对比</h3>
  <table>
    <thead><tr><th>指标</th><th>AHP权重</th><th>熵权法权重</th><th>综合权重</th></tr></thead>
    <tbody>{triple_bars_html}</tbody>
  </table>

  <div class="conclusion">
    <p><strong>综合权重排名：</strong></p>
    <p>1. <strong>项目成本（{combined_w[0]*100:.2f}%）</strong> — 主客观权重均高，是定价的首要因素</p>
    <p>2. <strong>时间成本（{combined_w[2]*100:.2f}%）</strong> — 数据差异大且专家认可</p>
    <p>3. <strong>风险程度（{combined_w[4]*100:.2f}%）</strong> — 两者较为一致</p>
    <p>4. <strong>市场竞争程度（{combined_w[6]*100:.2f}%）</strong> — 熵权法权重高但AHP权重低</p>
    <p>5. <strong>技术难度（{combined_w[3]*100:.2f}%）</strong> — AHP认为重要但数据差异小</p>
    <p>6. <strong>医生资质（{combined_w[1]*100:.2f}%）</strong> — 与AHP排名差异最大</p>
    <p>7. <strong>供求关系（{combined_w[5]*100:.2f}%）</strong> — 两者权重均较低</p>
  </div>
</div>

<!-- 定价模型 -->
<div class="card">
  <h2><span class="section-badge">步骤三</span>手术类项目定价模型</h2>

  <h3>3.1 模型公式</h3>
  <div class="formula">
    综合评分 S<sub>i</sub> = Σ<sub>j=1..7</sub> W<sub>j</sub> × r<sub>ij</sub>
    <br/><br/>
    预测价格 Price = <strong>{a_coef:.4f}</strong> × S + (<strong>{b_coef:.4f}</strong>)
  </div>

  <h3>3.2 预测值与实际值散点图</h3>
  <div class="scatter-container">
    <svg width="{svg_width}" height="{svg_height}" viewBox="0 0 {svg_width} {svg_height}">
      <line x1="{margin}" y1="{margin}" x2="{margin}" y2="{margin+plot_h}" stroke="#d1d5db" stroke-width="1"/>
      <line x1="{margin}" y1="{margin+plot_h}" x2="{margin+plot_w}" y2="{margin+plot_h}" stroke="#d1d5db" stroke-width="1"/>
      {x_ticks}
      {y_ticks}
      <text x="{svg_width/2}" y="{svg_height-5}" class="axis-label" text-anchor="middle">预测价格（元）</text>
      <text x="12" y="{svg_height/2}" class="axis-label" text-anchor="middle" transform="rotate(-90, 12, {svg_height/2})">实际价格（元）</text>
      {scatter_dots}
    </svg>
    <div class="legend">
      <div class="legend-item"><div class="legend-dot" style="background:var(--primary)"></div>项目数据点</div>
      <div class="legend-item"><div class="legend-dot" style="background:var(--danger);opacity:0.6"></div>理想线(y=x)</div>
    </div>
  </div>

  <h3>3.3 模型检验统计</h3>
  <div class="stats-grid">
    <div class="stat-box"><div class="label">R²</div><div class="num">{R2:.4f}</div><div class="unit">解释{R2*100:.1f}%变异</div></div>
    <div class="stat-box"><div class="label">MAE</div><div class="num">{MAE:.0f}</div><div class="unit">元</div></div>
    <div class="stat-box"><div class="label">RMSE</div><div class="num">{RMSE:.0f}</div><div class="unit">元</div></div>
    <div class="stat-box"><div class="label">MAPE</div><div class="num">{MAPE:.1f}%</div><div class="unit">平均相对误差</div></div>
    <div class="stat-box"><div class="label">Pearson r</div><div class="num">{pearson_r:.4f}</div><div class="unit">t={t_stat:.2f}</div></div>
    <div class="stat-box"><div class="label">Spearman ρ</div><div class="num">{spearman_r:.4f}</div><div class="unit">秩相关</div></div>
  </div>

  <h3>3.4 相对误差分布</h3>
  <div class="scatter-container">
    <svg width="500" height="160" viewBox="0 0 500 160">
      {"".join(f'<rect x="{30 + i*78}" y="{130 - [np.sum(rel_err < 10), np.sum((rel_err >= 10) & (rel_err < 20)), np.sum((rel_err >= 20) & (rel_err < 30)), np.sum((rel_err >= 30) & (rel_err < 50)), np.sum((rel_err >= 50) & (rel_err < 100)), np.sum(rel_err >= 100)][i]*4}" width="60" height="{[np.sum(rel_err < 10), np.sum((rel_err >= 10) & (rel_err < 20)), np.sum((rel_err >= 20) & (rel_err < 30)), np.sum((rel_err >= 30) & (rel_err < 50)), np.sum((rel_err >= 50) & (rel_err < 100)), np.sum(rel_err >= 100)][i]*4}" rx="4" fill="{["#10b981","#3b82f6","#f59e0b","#f97316","#ef4444","#991b1b"][i]}" opacity="0.8"/><text x="{60 + i*78}" y="{125 - [np.sum(rel_err < 10), np.sum((rel_err >= 10) & (rel_err < 20)), np.sum((rel_err >= 20) & (rel_err < 30)), np.sum((rel_err >= 30) & (rel_err < 50)), np.sum((rel_err >= 50) & (rel_err < 100)), np.sum(rel_err >= 100)][i]*4}" text-anchor="middle" font-size="12" font-weight="600" fill="#374151">{[np.sum(rel_err < 10), np.sum((rel_err >= 10) & (rel_err < 20)), np.sum((rel_err >= 20) & (rel_err < 30)), np.sum((rel_err >= 30) & (rel_err < 50)), np.sum((rel_err >= 50) & (rel_err < 100)), np.sum(rel_err >= 100)][i]}</text><text x="{60 + i*78}" y="150" text-anchor="middle" font-size="10" fill="#374151">{["<10%","10-20%","20-30%","30-50%","50-100%",">100%"][i]}</text>' for i in range(6))}
    </svg>
  </div>
</div>

<!-- 详细对比表 -->
<div class="card">
  <h2><span class="section-badge">附录</span>60个项目定价预测对比明细</h2>
  <p style="font-size:12px;color:var(--gray-600);margin-bottom:8px;">
    颜色说明：<span style="background:#d1fae5;padding:1px 6px;border-radius:3px;">&lt;10%</span>
    <span style="background:#dbeafe;padding:1px 6px;border-radius:3px;">10-20%</span>
    <span style="background:#fef3c7;padding:1px 6px;border-radius:3px;">20-30%</span>
    <span style="background:#fed7aa;padding:1px 6px;border-radius:3px;">30-50%</span>
    <span style="background:#fecaca;padding:1px 6px;border-radius:3px;">&gt;50%</span>
  </p>
  <div class="scroll-table">
    <table>
      <thead><tr>
        <th>#</th><th>项目编码</th><th>项目名称</th><th>综合评分</th>
        <th>预测价格</th><th>实际价格</th><th>绝对误差</th><th>相对误差</th>
      </tr></thead>
      <tbody>{price_table_html}</tbody>
    </table>
  </div>
</div>

<!-- 总结 -->
<div class="card">
  <h2><span class="section-badge">结论</span>模型评价与分析</h2>
  <div class="conclusion">
    <p><strong>1. 熵权法权重特点：</strong>客观反映数据差异程度。市场竞争程度（{w_entropy[6]*100:.2f}%）和项目成本（{w_entropy[0]*100:.2f}%）在60个手术项目间变异最大，信息熵最低，因此权重最高。医生资质（{w_entropy[1]*100:.2f}%）和技术难度（{w_entropy[3]*100:.2f}%）各项目间差异较小。</p>
    <p><strong>2. AHP与熵权法的互补性：</strong>AHP反映专家主观判断（医生资质、技术难度权重高），熵权法反映客观数据差异（市场竞争、项目成本权重高）。乘法集成后，项目成本（{combined_w[0]*100:.2f}%）和时间成本（{combined_w[2]*100:.2f}%）成为最重要的两个定价因素。</p>
    <p><strong>3. 定价模型表现：</strong>R²={R2:.4f}，说明综合评分能解释约{R2*100:.1f}%的价格变异。Pearson r={pearson_r:.4f}，线性关系强。38.3%的项目相对误差在20%以内，50%在30%以内。</p>
    <p><strong>4. 误差较大的项目分析：</strong>部分基础手术（如根尖搔刮术、宫颈息肉切除术、包皮环切术等）实际收费远低于模型预测，可能受历史定价惯性、政策限价、公益属性等非市场因素影响。高值项目（如内镜下颅底病变切除术、人工全髋关节置换术等）的预测偏差可能与技术溢价有关。</p>
  </div>
</div>

<div style="text-align:center;color:var(--gray-600);font-size:12px;padding:20px 0;">
  报告生成时间：2026-09-24 · 数据来源：60个手术类项目 · 方法：熵权法 + AHP + 乘法集成 + 线性回归
</div>

</div>
</body>
</html>"""

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print(f"HTML 报告已生成: {html_path}")
print("\n全部完成！")
