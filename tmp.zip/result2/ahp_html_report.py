# -*- coding: utf-8 -*-
"""Generate AHP analysis report as HTML"""

import pandas as pd
import numpy as np
import json

# ---- Re-run analysis to get all data ----
df = pd.read_excel(r'D:\tmp\层次分析法（问卷数据）.xlsx')

col_names = [
    "问卷编号",
    "项目成本 VS 医生资质", "项目成本 VS 时间成本", "项目成本 VS 技术难度",
    "项目成本 VS 风险程度", "项目成本 VS 供求关系", "项目成本 VS 市场竞争程度",
    "医生资质 VS 时间成本", "医生资质 VS 技术难度", "医生资质 VS 风险程度",
    "医生资质 VS 供求关系", "医生资质 VS 市场竞争程度",
    "时间成本 VS 技术难度", "时间成本 VS 风险程度",
    "时间成本 VS 供求关系", "时间成本 VS 市场竞争程度",
    "技术难度 VS 风险程度", "技术难度 VS 供求关系", "技术难度 VS 市场竞争程度",
    "风险程度 VS 供求关系", "风险程度 VS 市场竞争程度",
    "供求关系 VS 市场竞争程度"
]
df.columns = col_names

n_criteria = 7
criteria = ["项目成本", "医生资质", "时间成本", "技术难度", "风险程度", "供求关系", "市场竞争程度"]

pair_mapping = [
    (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6),
    (1, 2), (1, 3), (1, 4), (1, 5), (1, 6),
    (2, 3), (2, 4), (2, 5), (2, 6),
    (3, 4), (3, 5), (3, 6),
    (4, 5), (4, 6),
    (5, 6)
]

total_questionnaires = len(df)
comparison_cols = col_names[1:]

valid_values = set()
for i in range(1, 10):
    valid_values.add(float(i))
    valid_values.add(round(1.0 / i, 4))

invalid_questionnaires = []
valid_df = df.copy()

null_rows = valid_df[valid_df[comparison_cols].isnull().any(axis=1)]
if len(null_rows) > 0:
    for idx, row in null_rows.iterrows():
        qid = int(row['问卷编号'])
        invalid_questionnaires.append({'编号': qid, '原因': '存在缺失值', '类型': '缺失值'})

valid_df_check = valid_df[~valid_df['问卷编号'].isin([q['编号'] for q in invalid_questionnaires])]
for idx, row in valid_df_check.iterrows():
    qid = int(row['问卷编号'])
    invalid_vals = []
    for col in comparison_cols:
        val = row[col]
        is_valid = any(abs(val - v) < 0.01 for v in valid_values)
        if not is_valid:
            invalid_vals.append(val)
    if invalid_vals:
        invalid_questionnaires.append({'编号': qid, '原因': f'存在非法AHP值', '类型': '非法值'})

valid_ids = set(valid_df['问卷编号'].astype(int)) - set(q['编号'] for q in invalid_questionnaires)
all_ones_ids = []
for idx, row in valid_df.iterrows():
    qid = int(row['问卷编号'])
    if qid not in valid_ids:
        continue
    if all(abs(row[col] - 1.0) < 0.01 for col in comparison_cols):
        all_ones_ids.append(qid)
        invalid_questionnaires.append({'编号': qid, '原因': '所有比较值均为1（无区分度）', '类型': '无区分度'})

valid_ids = set(valid_df['问卷编号'].astype(int)) - set(q['编号'] for q in invalid_questionnaires)
extreme_ids = []
for idx, row in valid_df.iterrows():
    qid = int(row['问卷编号'])
    if qid not in valid_ids:
        continue
    vals = [row[col] for col in comparison_cols]
    if all(v >= 7 for v in vals):
        extreme_ids.append(qid)
        invalid_questionnaires.append({'编号': qid, '原因': '所有比较值均>=7（极端一致性异常）', '类型': '极端异常'})

invalid_ids = set(q['编号'] for q in invalid_questionnaires)
valid_df_final = valid_df[~valid_df['问卷编号'].astype(int).isin(invalid_ids)].copy()

def build_matrix(row, pair_mapping, n):
    matrix = np.ones((n, n))
    for k, (i, j) in enumerate(pair_mapping):
        val = row.iloc[k + 1]
        matrix[i][j] = val
        matrix[j][i] = 1.0 / val
    return matrix

def ahp_weights(matrix):
    n = matrix.shape[0]
    eigenvalues, eigenvectors = np.linalg.eig(matrix)
    max_idx = np.argmax(eigenvalues.real)
    max_eigenvalue = eigenvalues[max_idx].real
    max_eigenvector = eigenvectors[:, max_idx].real
    weights = max_eigenvector / max_eigenvector.sum()
    if weights.sum() < 0:
        weights = -weights
    weights = weights / weights.sum()
    return weights, max_eigenvalue

individual_matrices = []
for idx, row in valid_df_final.iterrows():
    qid = int(row['问卷编号'])
    mat = build_matrix(row, pair_mapping, n_criteria)
    individual_matrices.append((qid, mat))

aggregated_matrix = np.ones((n_criteria, n_criteria))
for i in range(n_criteria):
    for j in range(n_criteria):
        if i == j:
            aggregated_matrix[i][j] = 1.0
        else:
            vals = [mat[i][j] for _, mat in individual_matrices]
            aggregated_matrix[i][j] = np.exp(np.mean(np.log(vals)))

weights, lambda_max = ahp_weights(aggregated_matrix)
CI = (lambda_max - n_criteria) / (n_criteria - 1)
RI_table = {1: 0, 2: 0, 3: 0.58, 4: 0.90, 5: 1.12, 6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
RI = RI_table[n_criteria]
CR = CI / RI

results = sorted(zip(criteria, weights), key=lambda x: x[1], reverse=True)

individual_cr_values = []
for qid, mat in individual_matrices:
    w, lmax = ahp_weights(mat)
    ci = (lmax - n_criteria) / (n_criteria - 1)
    cr = ci / RI if RI > 0 else 0
    individual_cr_values.append((qid, cr))

cr_vals = [cr for _, cr in individual_cr_values]
passed_count = sum(1 for _, cr in individual_cr_values if cr < 0.1)

# Categorize invalid
no_disc = [q for q in invalid_questionnaires if q['类型'] == '无区分度']
extreme = [q for q in invalid_questionnaires if q['类型'] == '极端异常']
other_inv = [q for q in invalid_questionnaires if q['类型'] not in ('无区分度', '极端异常')]

# ---- Generate HTML ----
html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>层次分析法(AHP)问卷分析报告</title>
<style>
  :root {{
    --primary: #2563eb;
    --primary-light: #dbeafe;
    --success: #16a34a;
    --success-light: #dcfce7;
    --danger: #dc2626;
    --danger-light: #fee2e2;
    --warning: #d97706;
    --warning-light: #fef3c7;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-500: #6b7280;
    --gray-700: #374151;
    --gray-900: #111827;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    background: var(--gray-50);
    color: var(--gray-900);
    line-height: 1.6;
  }}
  .container {{ max-width: 1100px; margin: 0 auto; padding: 40px 24px; }}

  /* Header */
  .header {{
    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
    color: white;
    padding: 48px 40px;
    border-radius: 16px;
    margin-bottom: 32px;
    box-shadow: 0 4px 24px rgba(37,99,235,0.18);
  }}
  .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
  .header p {{ font-size: 15px; opacity: 0.85; }}
  .header .meta {{ margin-top: 16px; display: flex; gap: 24px; flex-wrap: wrap; }}
  .header .meta span {{
    background: rgba(255,255,255,0.15);
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 13px;
    backdrop-filter: blur(4px);
  }}

  /* Card */
  .card {{
    background: white;
    border-radius: 12px;
    padding: 32px;
    margin-bottom: 24px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    border: 1px solid var(--gray-200);
  }}
  .card h2 {{
    font-size: 20px;
    font-weight: 600;
    color: var(--gray-900);
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--primary);
    display: flex;
    align-items: center;
    gap: 10px;
  }}
  .card h2 .step {{
    background: var(--primary);
    color: white;
    width: 32px; height: 32px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 700;
    flex-shrink: 0;
  }}

  /* Stats row */
  .stats {{ display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 20px; }}
  .stat-box {{
    flex: 1;
    min-width: 140px;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
  }}
  .stat-box.blue {{ background: var(--primary-light); }}
  .stat-box.green {{ background: var(--success-light); }}
  .stat-box.red {{ background: var(--danger-light); }}
  .stat-box.yellow {{ background: var(--warning-light); }}
  .stat-box .num {{ font-size: 32px; font-weight: 700; }}
  .stat-box.blue .num {{ color: var(--primary); }}
  .stat-box.green .num {{ color: var(--success); }}
  .stat-box.red .num {{ color: var(--danger); }}
  .stat-box.yellow .num {{ color: var(--warning); }}
  .stat-box .label {{ font-size: 13px; color: var(--gray-500); margin-top: 4px; }}

  /* Table */
  table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }}
  table.matrix {{
    font-family: "SF Mono", "Fira Code", "Consolas", monospace;
    font-size: 13px;
  }}
  th, td {{
    padding: 10px 14px;
    text-align: center;
    border: 1px solid var(--gray-200);
  }}
  th {{
    background: var(--gray-100);
    font-weight: 600;
    color: var(--gray-700);
    font-size: 13px;
  }}
  tr:nth-child(even) td {{ background: var(--gray-50); }}
  tr:hover td {{ background: #eef2ff; }}

  /* Matrix specific */
  table.matrix td {{ text-align: right; padding: 8px 12px; }}
  table.matrix th {{ text-align: center; white-space: nowrap; }}
  table.matrix .row-header {{ text-align: left; font-weight: 600; background: var(--gray-100); }}
  table.matrix .diag {{ background: #e0e7ff; font-weight: 600; color: var(--primary); }}
  table.matrix .upper {{ color: #1e40af; }}
  table.matrix .lower {{ color: #7c3aed; }}

  /* Weight bar */
  .weight-bar-wrapper {{ display: flex; align-items: center; gap: 8px; }}
  .weight-bar {{
    height: 22px;
    border-radius: 4px;
    background: linear-gradient(90deg, #3b82f6, #6366f1);
    transition: width 0.5s ease;
    min-width: 2px;
  }}
  .weight-pct {{ font-size: 13px; font-weight: 600; color: var(--primary); white-space: nowrap; }}

  /* Tags */
  .tag {{
    display: inline-block;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
  }}
  .tag-pass {{ background: var(--success-light); color: var(--success); }}
  .tag-fail {{ background: var(--danger-light); color: var(--danger); }}

  /* Badge list */
  .badge-list {{ display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }}
  .badge {{
    background: var(--danger-light);
    color: var(--danger);
    padding: 3px 10px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 500;
  }}
  .badge.gray {{ background: var(--gray-100); color: var(--gray-700); }}

  /* Consistency indicator */
  .consistency-box {{
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 20px 24px;
    border-radius: 10px;
    margin-top: 16px;
  }}
  .consistency-box.pass {{ background: var(--success-light); border: 1px solid #bbf7d0; }}
  .consistency-box .icon {{ font-size: 36px; }}
  .consistency-box .info h3 {{ font-size: 16px; margin-bottom: 4px; }}
  .consistency-box .info p {{ font-size: 13px; color: var(--gray-500); }}
  .consistency-box.pass .info h3 {{ color: var(--success); }}

  /* Formula */
  .formula {{
    background: var(--gray-100);
    padding: 16px 20px;
    border-radius: 8px;
    font-family: "SF Mono", "Fira Code", "Consolas", monospace;
    font-size: 14px;
    line-height: 2;
    margin: 12px 0;
    overflow-x: auto;
  }}

  /* Invalid list */
  .invalid-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 8px;
    margin-top: 12px;
  }}
  .invalid-item {{
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 13px;
    display: flex;
    justify-content: space-between;
  }}
  .invalid-item.type-a {{ background: #fef2f2; color: #991b1b; }}
  .invalid-item.type-b {{ background: #fff7ed; color: #9a3412; }}

  /* CR distribution */
  .cr-chart {{ display: flex; align-items: flex-end; gap: 2px; height: 80px; margin: 16px 0; }}
  .cr-bar {{
    flex: 1;
    background: var(--primary);
    border-radius: 2px 2px 0 0;
    min-width: 4px;
    transition: height 0.3s;
  }}
  .cr-bar.fail {{ background: var(--danger); }}
  .cr-line {{
    position: relative;
    height: 1px;
    background: var(--danger);
    margin-top: -1px;
    border-top: 2px dashed var(--danger);
  }}

  /* Footer */
  .footer {{
    text-align: center;
    padding: 24px;
    color: var(--gray-500);
    font-size: 13px;
  }}

  @media print {{
    body {{ background: white; }}
    .card {{ break-inside: avoid; box-shadow: none; border: 1px solid #ddd; }}
  }}
</style>
</head>
<body>
<div class="container">

<!-- Header -->
<div class="header">
  <h1>层次分析法 (AHP) 问卷分析报告</h1>
  <p>Analytic Hierarchy Process — Questionnaire Data Analysis Report</p>
  <div class="meta">
    <span>问卷总数: {total_questionnaires}</span>
    <span>有效问卷: {len(valid_df_final)}</span>
    <span>评价指标: {n_criteria} 个</span>
    <span>有效率: {len(valid_df_final)/total_questionnaires*100:.1f}%</span>
  </div>
</div>

<!-- Step 1: Overview -->
<div class="card">
  <h2><span class="step">1</span>数据概览</h2>
  <div class="stats">
    <div class="stat-box blue">
      <div class="num">{total_questionnaires}</div>
      <div class="label">问卷总数</div>
    </div>
    <div class="stat-box green">
      <div class="num">{len(valid_df_final)}</div>
      <div class="label">有效问卷</div>
    </div>
    <div class="stat-box red">
      <div class="num">{len(invalid_questionnaires)}</div>
      <div class="label">无效问卷</div>
    </div>
    <div class="stat-box yellow">
      <div class="num">{n_criteria}</div>
      <div class="label">评价指标</div>
    </div>
  </div>
  <p style="color:var(--gray-500); font-size:14px; margin-bottom:12px;">
    7个评价指标的两两比较共构成 C(7,2) = <strong>21</strong> 组比较对，采用Saaty 1-9标度法。
  </p>
  <table>
    <thead>
      <tr>
        <th>编号</th><th>指标名称</th><th>说明</th>
      </tr>
    </thead>
    <tbody>"""

criteria_desc = {
    "项目成本": "项目实施所需的经济成本",
    "医生资质": "医生的专业能力和资质水平",
    "时间成本": "项目所需的时间投入",
    "技术难度": "项目实施的技术复杂程度",
    "风险程度": "项目面临的不确定性和风险",
    "供求关系": "市场供需状况",
    "市场竞争程度": "市场竞争的激烈程度"
}
for i, c in enumerate(criteria, 1):
    html += f"""
      <tr><td>{i}</td><td><strong>{c}</strong></td><td style="text-align:left;color:var(--gray-500)">{criteria_desc[c]}</td></tr>"""

html += f"""
    </tbody>
  </table>
</div>

<!-- Step 2: Validation -->
<div class="card">
  <h2><span class="step">2</span>无效问卷剔除</h2>
  <p style="font-size:14px; color:var(--gray-500); margin-bottom:16px;">
    采用以下三种规则筛选无效问卷：
  </p>
  <table>
    <thead>
      <tr><th>剔除规则</th><th>说明</th><th>剔除数量</th></tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>缺失值检查</strong></td>
        <td style="text-align:left">存在空白未填项</td>
        <td>{len([q for q in invalid_questionnaires if q['类型']=='缺失值'])} 份</td>
      </tr>
      <tr>
        <td><strong>非法AHP值</strong></td>
        <td style="text-align:left">数值不在 {1,2,...,9, 1/2, 1/3,...,1/9} 范围内</td>
        <td>{len([q for q in invalid_questionnaires if q['类型']=='非法值'])} 份</td>
      </tr>
      <tr>
        <td><strong>无区分度</strong></td>
        <td style="text-align:left">所有比较值均为1，未体现任何偏好差异</td>
        <td><strong style="color:var(--danger)">{len(no_disc)} 份</strong></td>
      </tr>
      <tr>
        <td><strong>极端异常</strong></td>
        <td style="text-align:left">所有比较值均&ge;7，存在极端一致性偏差，疑似随意填写</td>
        <td><strong style="color:var(--warning)">{len(extreme)} 份</strong></td>
      </tr>
    </tbody>
  </table>

  <h3 style="font-size:15px; margin-top:24px; margin-bottom:12px; color:var(--gray-700);">
    被剔除的无区分度问卷 ({len(no_disc)} 份)
  </h3>
  <div class="badge-list">"""

for q in no_disc:
    html += f'\n    <span class="badge">#{q["编号"]}</span>'

html += f"""
  </div>

  <h3 style="font-size:15px; margin-top:20px; margin-bottom:12px; color:var(--gray-700);">
    被剔除的极端异常问卷 ({len(extreme)} 份)
  </h3>
  <div class="badge-list">"""

for q in extreme:
    html += f'\n    <span class="badge" style="background:#fff7ed;color:#9a3412">#{q["编号"]}</span>'

html += f"""
  </div>
</div>

<!-- Step 3: Aggregated Matrix -->
<div class="card">
  <h2><span class="step">3</span>综合判断矩阵</h2>
  <p style="font-size:14px; color:var(--gray-500); margin-bottom:16px;">
    采用<strong>几何平均法 (Geometric Mean Method)</strong> 将 {len(valid_df_final)} 份有效问卷的判断矩阵进行聚合。
    该方法能有效降低个体判断的极端值影响，是群体AHP决策中最常用的聚合方法。
  </p>
  <div style="overflow-x:auto">
  <table class="matrix">
    <thead>
      <tr>
        <th></th>"""
for c in criteria:
    html += f"<th>{c}</th>"
html += """
      </tr>
    </thead>
    <tbody>"""

for i in range(n_criteria):
    html += f"\n      <tr>\n        <td class='row-header'>{criteria[i]}</td>"
    for j in range(n_criteria):
        val = aggregated_matrix[i][j]
        cls = ""
        if i == j:
            cls = " class='diag'"
        elif j > i:
            cls = " class='upper'"
        else:
            cls = " class='lower'"
        html += f"<td{cls}>{val:.4f}</td>"
    html += "\n      </tr>"

html += f"""
    </tbody>
  </table>
  </div>
  <p style="font-size:12px; color:var(--gray-500); margin-top:8px;">
    蓝色数字为上三角（原始比较方向），紫色数字为下三角（倒数）
  </p>
</div>

<!-- Step 4: Consistency Check -->
<div class="card">
  <h2><span class="step">4</span>一致性检验</h2>
  <p style="font-size:14px; color:var(--gray-500); margin-bottom:16px;">
    为保证判断矩阵的逻辑一致性，需要计算一致性比率 CR。当 CR &lt; 0.1 时，矩阵具有可接受的一致性。
  </p>
  <div class="formula">
    <div>&lambda;<sub>max</sub> = {lambda_max:.6f}</div>
    <div>CI = (&lambda;<sub>max</sub> - n) / (n - 1) = ({lambda_max:.6f} - {n_criteria}) / {n_criteria - 1} = <strong>{CI:.6f}</strong></div>
    <div>RI = {RI} &nbsp;(7阶随机一致性指标)</div>
    <div>CR = CI / RI = {CI:.6f} / {RI} = <strong style="color:var(--success)">{CR:.4f}</strong></div>
  </div>
  <div class="consistency-box pass">
    <div class="icon">&#10004;</div>
    <div class="info">
      <h3>一致性检验通过</h3>
      <p>CR = {CR:.4f} &lt; 0.1，综合判断矩阵具有满意的一致性，权重计算结果可靠。</p>
    </div>
  </div>
</div>

<!-- Step 5: Weights -->
<div class="card">
  <h2><span class="step">5</span>各指标权重</h2>
  <p style="font-size:14px; color:var(--gray-500); margin-bottom:20px;">
    采用<strong>特征值法 (Eigenvalue Method)</strong> 计算权重，权重之和为 1。
  </p>
  <table>
    <thead>
      <tr>
        <th style="width:50px">排名</th>
        <th style="width:140px">指标名称</th>
        <th style="width:100px">权重值</th>
        <th>权重分布</th>
        <th style="width:80px">百分比</th>
      </tr>
    </thead>
    <tbody>"""

max_w = results[0][1]
colors = ['#2563eb','#6366f1','#8b5cf6','#a855f7','#06b6d4','#14b8a6','#22c55e']
for rank, (name, w) in enumerate(results, 1):
    bar_pct = w / max_w * 100
    html += f"""
      <tr>
        <td><strong>{rank}</strong></td>
        <td><strong>{name}</strong></td>
        <td>{w:.6f}</td>
        <td>
          <div class="weight-bar-wrapper">
            <div class="weight-bar" style="width:{bar_pct:.0f}%;background:linear-gradient(90deg,{colors[rank-1]},{colors[rank-1]}aa)"></div>
          </div>
        </td>
        <td><span class="weight-pct">{w*100:.2f}%</span></td>
      </tr>"""

html += f"""
      <tr style="background:var(--gray-100);font-weight:600">
        <td></td><td>合计</td><td>{sum(w for _,w in results):.6f}</td><td></td><td>100.00%</td>
      </tr>
    </tbody>
  </table>
</div>

<!-- Step 6: Individual CR -->
<div class="card">
  <h2><span class="step">6</span>个体问卷一致性检验</h2>
  <div class="stats">
    <div class="stat-box green">
      <div class="num">{passed_count}</div>
      <div class="label">通过 (CR&lt;0.1)</div>
    </div>
    <div class="stat-box red">
      <div class="num">{len(individual_cr_values) - passed_count}</div>
      <div class="label">未通过</div>
    </div>
    <div class="stat-box blue">
      <div class="num">{passed_count/len(individual_cr_values)*100:.1f}%</div>
      <div class="label">通过率</div>
    </div>
    <div class="stat-box yellow">
      <div class="num">{np.median(cr_vals):.4f}</div>
      <div class="label">CR中位数</div>
    </div>
  </div>

  <p style="font-size:14px; color:var(--gray-500); margin-bottom:12px;">
    <strong>说明：</strong>个体问卷一致性通过率较低 ({passed_count/len(individual_cr_values)*100:.1f}%)
    在AHP群体决策中是常见现象。7个指标的两两比较达21对，普通受访者难以保证完全逻辑自洽。
    但通过几何平均聚合后，综合矩阵 CR = {CR:.4f} &lt; 0.1，满足一致性要求，权重结果可靠。
  </p>

  <h3 style="font-size:15px; margin-top:20px; margin-bottom:12px; color:var(--gray-700);">CR 值分布</h3>
  <table>
    <thead>
      <tr><th>统计量</th><th>最小值</th><th>最大值</th><th>均值</th><th>中位数</th></tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>CR</strong></td>
        <td>{min(cr_vals):.4f}</td>
        <td>{max(cr_vals):.4f}</td>
        <td>{np.mean(cr_vals):.4f}</td>
        <td>{np.median(cr_vals):.4f}</td>
      </tr>
    </tbody>
  </table>

  <h3 style="font-size:15px; margin-top:24px; margin-bottom:12px; color:var(--gray-700);">各问卷CR值明细</h3>
  <div style="max-height:400px;overflow-y:auto">
  <table>
    <thead>
      <tr><th>问卷编号</th><th>CR值</th><th>结果</th></tr>
    </thead>
    <tbody>"""

for qid, cr in sorted(individual_cr_values, key=lambda x: x[1]):
    tag = '<span class="tag tag-pass">PASS</span>' if cr < 0.1 else '<span class="tag tag-fail">FAIL</span>'
    style = '' if cr < 0.1 else ' style="background:#fff5f5"'
    html += f"\n      <tr{style}><td>#{qid}</td><td>{cr:.4f}</td><td>{tag}</td></tr>"

html += f"""
    </tbody>
  </table>
  </div>
</div>

<!-- Step 7: Conclusion -->
<div class="card">
  <h2><span class="step">7</span>分析结论</h2>
  <div style="font-size:15px; line-height:1.8">
    <p>本次层次分析法基于 <strong>{len(valid_df_final)}</strong> 份有效问卷（有效率 {len(valid_df_final)/total_questionnaires*100:.1f}%），
    对7个评价指标进行了权重分析。主要结论如下：</p>
    <ol style="margin-top:12px; padding-left:24px">
      <li style="margin-bottom:8px">
        <strong>项目成本</strong>（{results[0][1]*100:.2f}%）和<strong>医生资质</strong>（{results[1][1]*100:.2f}%）权重最为接近，
        是决策中最重要的两个指标，合计占比 {(results[0][1]+results[1][1])*100:.1f}%。
      </li>
      <li style="margin-bottom:8px">
        <strong>技术难度</strong>（{results[2][1]*100:.2f}%）和<strong>风险程度</strong>（{results[3][1]*100:.2f}%）
        属于第二梯队，权重占比也较高。
      </li>
      <li style="margin-bottom:8px">
        <strong>时间成本</strong>（{results[4][1]*100:.2f}%）、<strong>供求关系</strong>（{results[5][1]*100:.2f}%）
        和<strong>市场竞争程度</strong>（{results[6][1]*100:.2f}%）权重相对较低。
      </li>
      <li style="margin-bottom:8px">
        综合判断矩阵一致性比率 CR = {CR:.4f} &lt; 0.1，<strong>通过一致性检验</strong>，权重结果可信。
      </li>
    </ol>
  </div>
</div>

<div class="footer">
  Generated by AHP Analysis Tool &middot; {total_questionnaires} questionnaires processed &middot; {len(valid_df_final)} valid
</div>

</div>
</body>
</html>"""

with open(r'D:\tmp\AHP_分析报告.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Done. HTML report saved to D:\\tmp\\AHP_分析报告.html")
