# -*- coding: utf-8 -*-
"""
AHP questionnaire data processing and analysis
Output to file to avoid Windows console encoding issues
"""

import pandas as pd
import numpy as np
import json
import sys
import io

# Redirect stdout to file
output_file = open(r'D:\tmp\ahp_report.txt', 'w', encoding='utf-8')

def p(text=""):
    output_file.write(str(text) + "\n")

# ============================================================
# 1. Read data
# ============================================================
p("=" * 70)
p("           AHP questionnaire data analysis report")
p("=" * 70)

df = pd.read_excel(r'D:\tmp\层次分析法（问卷数据）.xlsx')

col_names = [
    "问卷编号",
    "项目成本 VS 医生资质", "项目成本 VS 时间成本", "项目成本 VS 技术难度",
    "项目成本 VS 风险程度", "项目成本 VS 供求关系", "项目成本 VS 市场竞争程度",
    "医生资质 VS 时间成本", "医生资质 VS 技术难度", "医生资质 VS 风险程度",
    "医生资质 VS 供求关系", "医生资质 VS 市场竞争程度",
    "时间成本 VS 技术难度", "时间成本 VS 风险程度",
    "时间成本 VS 供求关系", "时间成本 VS 市场竞争程度",
    "技术难度 VS 风险程度", "技术难度 VS 供求关系", "技术难度 VS 市场竞争程度",
    "风险程度 VS 供求关系", "风险程度 VS 市场竞争程度",
    "供求关系 VS 市场竞争程度"
]
df.columns = col_names

n_criteria = 7
criteria = ["项目成本", "医生资质", "时间成本", "技术难度", "风险程度", "供求关系", "市场竞争程度"]

pair_mapping = [
    (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6),
    (1, 2), (1, 3), (1, 4), (1, 5), (1, 6),
    (2, 3), (2, 4), (2, 5), (2, 6),
    (3, 4), (3, 5), (3, 6),
    (4, 5), (4, 6),
    (5, 6)
]

total_questionnaires = len(df)
p(f"\n{'~' * 70}")
p(f"[Step 1] Data Overview")
p(f"{'~' * 70}")
p(f"  Total questionnaires: {total_questionnaires}")
p(f"  Number of criteria: {n_criteria}")
p(f"  Pairwise comparisons: {len(pair_mapping)}")
p(f"  Criteria: {', '.join(criteria)}")

# ============================================================
# 2. Validation and invalid questionnaire removal
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 2] Data Validation and Invalid Questionnaire Removal")
p(f"{'~' * 70}")

valid_values = set()
for i in range(1, 10):
    valid_values.add(float(i))
    valid_values.add(round(1.0 / i, 4))

comparison_cols = col_names[1:]

invalid_questionnaires = []
valid_df = df.copy()

# Check 1: Missing values
null_rows = valid_df[valid_df[comparison_cols].isnull().any(axis=1)]
if len(null_rows) > 0:
    for idx, row in null_rows.iterrows():
        qid = int(row['问卷编号'])
        null_cols = row[comparison_cols][row[comparison_cols].isnull()].index.tolist()
        invalid_questionnaires.append({
            '编号': qid, '原因': f'存在缺失值: {null_cols}', '类型': '缺失值'
        })
        p(f"  [X] Questionnaire {qid}: Missing values found")

# Check 2: Invalid AHP scale values
valid_df_check = valid_df[~valid_df['问卷编号'].isin([q['编号'] for q in invalid_questionnaires])]
for idx, row in valid_df_check.iterrows():
    qid = int(row['问卷编号'])
    invalid_vals = []
    for col in comparison_cols:
        val = row[col]
        is_valid = False
        for v in valid_values:
            if abs(val - v) < 0.01:
                is_valid = True
                break
        if not is_valid:
            invalid_vals.append((col, val))
    if invalid_vals:
        invalid_questionnaires.append({
            '编号': qid,
            '原因': f'非法AHP值: {[(c, round(v,2)) for c,v in invalid_vals]}',
            '类型': '非法值'
        })
        p(f"  [X] Questionnaire {qid}: Invalid AHP values {[round(v,2) for _,v in invalid_vals]}")

# Check 3: All values = 1 (no discrimination)
valid_ids = set(valid_df['问卷编号'].astype(int)) - set(q['编号'] for q in invalid_questionnaires)
for idx, row in valid_df.iterrows():
    qid = int(row['问卷编号'])
    if qid not in valid_ids:
        continue
    if all(abs(row[col] - 1.0) < 0.01 for col in comparison_cols):
        invalid_questionnaires.append({
            '编号': qid, '原因': '所有比较值均为1（无区分度）', '类型': '无区分度'
        })
        p(f"  [X] Questionnaire {qid}: All values = 1 (no discrimination)")

# Check 4: Extreme consistency anomaly (all values >= 7)
valid_ids = set(valid_df['问卷编号'].astype(int)) - set(q['编号'] for q in invalid_questionnaires)
for idx, row in valid_df.iterrows():
    qid = int(row['问卷编号'])
    if qid not in valid_ids:
        continue
    vals = [row[col] for col in comparison_cols]
    if all(v >= 7 for v in vals):
        invalid_questionnaires.append({
            '编号': qid, '原因': '所有比较值均>=7（极端一致性异常，可能随意填写）', '类型': '极端异常'
        })
        p(f"  [X] Questionnaire {qid}: All values >= 7 (extreme anomaly)")

invalid_ids = set(q['编号'] for q in invalid_questionnaires)
valid_df_final = valid_df[~valid_df['问卷编号'].astype(int).isin(invalid_ids)].copy()

p(f"\n  Validation Summary:")
p(f"     Invalid: {len(invalid_questionnaires)}")
p(f"     Valid:   {len(valid_df_final)}")
p(f"     Valid rate: {len(valid_df_final)/total_questionnaires*100:.1f}%")

if invalid_questionnaires:
    p(f"\n  Invalid questionnaire details:")
    for q in invalid_questionnaires:
        p(f"     - #{q['编号']}: {q['原因']}")

# ============================================================
# 3. Build individual judgment matrices
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 3] Build Individual Judgment Matrices")
p(f"{'~' * 70}")

def build_matrix(row, pair_mapping, n):
    matrix = np.ones((n, n))
    for k, (i, j) in enumerate(pair_mapping):
        val = row.iloc[k + 1]
        matrix[i][j] = val
        matrix[j][i] = 1.0 / val
    return matrix

individual_matrices = []
for idx, row in valid_df_final.iterrows():
    qid = int(row['问卷编号'])
    mat = build_matrix(row, pair_mapping, n_criteria)
    individual_matrices.append((qid, mat))

p(f"  [OK] Built {len(individual_matrices)} individual judgment matrices")

for qid, mat in individual_matrices[:3]:
    p(f"\n  Example - Questionnaire {qid} matrix:")
    p(f"  {'':>12s} {'':>10s}{'':>10s}{'':>10s}{'':>10s}{'':>10s}{'':>10s}{'':>10s}")
    for i in range(n_criteria):
        row_str = f"  {criteria[i]:>10s} |"
        for j in range(n_criteria):
            row_str += f"{mat[i][j]:10.4f}"
        p(row_str)

# ============================================================
# 4. Geometric mean aggregation
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 4] Aggregated Judgment Matrix (Geometric Mean Method)")
p(f"{'~' * 70}")

aggregated_matrix = np.ones((n_criteria, n_criteria))
for i in range(n_criteria):
    for j in range(n_criteria):
        if i == j:
            aggregated_matrix[i][j] = 1.0
        else:
            vals = [mat[i][j] for _, mat in individual_matrices]
            aggregated_matrix[i][j] = np.exp(np.mean(np.log(vals)))

p("\n  Aggregated Matrix:")
header = f"  {'':>12s}"
for c in criteria:
    header += f"{c:>10s}"
p(header)
p("  " + "-" * (12 + 10 * n_criteria))
for i in range(n_criteria):
    row_str = f"  {criteria[i]:>10s} |"
    for j in range(n_criteria):
        row_str += f"{aggregated_matrix[i][j]:10.4f}"
    p(row_str)

# ============================================================
# 5. Calculate weights (eigenvalue method)
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 5] Weight Calculation (Eigenvalue Method)")
p(f"{'~' * 70}")

def ahp_weights(matrix):
    n = matrix.shape[0]
    eigenvalues, eigenvectors = np.linalg.eig(matrix)
    max_idx = np.argmax(eigenvalues.real)
    max_eigenvalue = eigenvalues[max_idx].real
    max_eigenvector = eigenvectors[:, max_idx].real
    weights = max_eigenvector / max_eigenvector.sum()
    if weights.sum() < 0:
        weights = -weights
    weights = weights / weights.sum()
    return weights, max_eigenvalue

weights, lambda_max = ahp_weights(aggregated_matrix)

# ============================================================
# 6. Consistency check
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 6] Consistency Check")
p(f"{'~' * 70}")

n = n_criteria
CI = (lambda_max - n) / (n - 1)
RI_table = {1: 0, 2: 0, 3: 0.58, 4: 0.90, 5: 1.12, 6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
RI = RI_table[n]
CR = CI / RI if RI > 0 else 0

p(f"\n  Matrix order n = {n}")
p(f"  Max eigenvalue lambda_max = {lambda_max:.6f}")
p(f"  CI = (lambda_max - n) / (n - 1) = ({lambda_max:.6f} - {n}) / {n-1} = {CI:.6f}")
p(f"  RI = {RI}")
p(f"  CR = CI / RI = {CI:.6f} / {RI} = {CR:.6f}")
if CR < 0.1:
    p(f"\n  [OK] CR = {CR:.4f} < 0.1, PASSED consistency check!")
else:
    p(f"\n  [!!] CR = {CR:.4f} >= 0.1, FAILED consistency check!")

# ============================================================
# 7. Final weight results
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 7] Criteria Weights Results")
p(f"{'~' * 70}")

results = sorted(zip(criteria, weights), key=lambda x: x[1], reverse=True)
p(f"\n  {'Rank':>4s}  {'Criteria':>12s}  {'Weight':>10s}  {'Percent':>8s}")
p(f"  {'-' * 50}")
for rank, (name, w) in enumerate(results, 1):
    bar = '#' * int(w * 50)
    p(f"  {rank:>4d}  {name:>12s}  {w:>10.6f}  {w*100:>7.2f}%  {bar}")
p(f"  {'-' * 50}")
p(f"  {'Total':>18s}  {sum(weights):>10.6f}  {sum(weights)*100:>7.2f}%")

# ============================================================
# 8. Individual consistency checks
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 8] Individual Questionnaire Consistency Check")
p(f"{'~' * 70}")

individual_cr_values = []
passed_count = 0
for qid, mat in individual_matrices:
    w, lmax = ahp_weights(mat)
    ci = (lmax - n) / (n - 1)
    cr = ci / RI if RI > 0 else 0
    individual_cr_values.append((qid, cr))
    if cr < 0.1:
        passed_count += 1

p(f"\n  Individual consistency results:")
p(f"     Passed (CR<0.1): {passed_count}")
p(f"     Failed: {len(individual_cr_values) - passed_count}")
p(f"     Pass rate: {passed_count/len(individual_cr_values)*100:.1f}%")

cr_vals = [cr for _, cr in individual_cr_values]
p(f"\n  CR statistics:")
p(f"     Min: {min(cr_vals):.4f}")
p(f"     Max: {max(cr_vals):.4f}")
p(f"     Mean: {np.mean(cr_vals):.4f}")
p(f"     Median: {np.median(cr_vals):.4f}")

failed = [(qid, cr) for qid, cr in individual_cr_values if cr >= 0.1]
if failed:
    p(f"\n  Failed questionnaires:")
    for qid, cr in sorted(failed, key=lambda x: x[1], reverse=True):
        p(f"     #{qid}: CR = {cr:.4f}")

# ============================================================
# 9. Save results
# ============================================================
p(f"\n{'~' * 70}")
p(f"[Step 9] Save Results")
p(f"{'~' * 70}")

with open(r'D:\tmp\AHP_aggregated_matrix.json', 'w', encoding='utf-8') as f:
    json.dump({
        'criteria': criteria,
        'matrix': aggregated_matrix.tolist(),
        'lambda_max': float(lambda_max),
        'CI': float(CI), 'RI': float(RI), 'CR': float(CR)
    }, f, ensure_ascii=False, indent=2)
p(f"  [OK] Aggregated matrix -> D:\\tmp\\AHP_aggregated_matrix.json")

with open(r'D:\tmp\AHP_weights.json', 'w', encoding='utf-8') as f:
    json.dump({
        'weights_ranking': [{'rank': i+1, 'criteria': name, 'weight': round(float(w), 6), 'percent': f"{w*100:.2f}%"}
                   for i, (name, w) in enumerate(results)],
        'consistency_check': {
            'lambda_max': round(float(lambda_max), 6), 'CI': round(float(CI), 6),
            'RI': float(RI), 'CR': round(float(CR), 6), 'passed': bool(CR < 0.1)
        },
        'questionnaire_stats': {
            'total': total_questionnaires, 'valid': len(valid_df_final),
            'invalid': len(invalid_questionnaires),
            'valid_rate': f"{len(valid_df_final)/total_questionnaires*100:.1f}%",
            'invalid_details': invalid_questionnaires
        }
    }, f, ensure_ascii=False, indent=2)
p(f"  [OK] Weights -> D:\\tmp\\AHP_weights.json")

with open(r'D:\tmp\AHP_individual_CR.json', 'w', encoding='utf-8') as f:
    json.dump({
        'individual_CR': [{'id': int(qid), 'CR': round(float(cr), 4), 'passed': bool(cr < 0.1)}
                   for qid, cr in individual_cr_values]
    }, f, ensure_ascii=False, indent=2)
p(f"  [OK] Individual CR -> D:\\tmp\\AHP_individual_CR.json")

p(f"\n{'=' * 70}")
p(f"                    Analysis Complete!")
p(f"{'=' * 70}")

output_file.close()
print("Done. Report saved to D:\\tmp\\ahp_report.txt")
